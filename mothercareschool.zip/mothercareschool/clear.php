<?php
require_once("config.php");

mysqli_query($conn, "TRUNCATE TABLE admiria_registrations");

echo "done";
?>