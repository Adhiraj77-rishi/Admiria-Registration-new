<?php
require_once("config.php");

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM admiria_registrations WHERE id = $id");

echo "done";
?>