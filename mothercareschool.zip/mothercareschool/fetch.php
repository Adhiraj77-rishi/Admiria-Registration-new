<?php
require_once("config.php");

$result = mysqli_query($conn, "SELECT * FROM admiria_registrations ORDER BY id DESC");

$data = [];

while($row = mysqli_fetch_assoc($result)) {
    $data[] = [
        "id" => $row['id'],
        "name" => $row['name'],
        "std" => $row['std'],
        "division" => $row['division'],
        "contact" => $row['contact'],
        "parent" => $row['parent'],
        "time" => date("d/m/Y, h:i A", strtotime($row['created_at']))
    ];
}

echo json_encode($data);
?>