<?php
require_once("config.php");

$name     = $_POST['name'];
$std      = $_POST['std'];
$division = $_POST['division'];
$contact  = $_POST['contact'];
$parent   = $_POST['parent'];

if (!$name || !$std || !$contact) {
    echo "error";
    exit;
}

$query = "INSERT INTO admiria_registrations (name, std, division, contact, parent) 
          VALUES ('$name', '$std', '$division', '$contact', '$parent')";

if (mysqli_query($conn, $query)) {
    echo "success";
} else {
    echo "error";
}
?>