<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ADMIRIA 1.0 — Register Now</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

:root {
–c1: #ff6b35;
–c2: #f7c59f;
–c3: #efefd0;
–c4: #004e89;
–c5: #1a936f;
–bg: #0d0d0d;
–surface: #161616;
–border: rgba(255,107,53,0.25);
–text: #f5f5f5;
–muted: #888;
}

body {
font-family: ‘Poppins’, sans-serif;
background: var(–bg);
color: var(–text);
min-height: 100vh;
overflow-x: hidden;
}

/* Animated mesh background */
.bg-mesh {
position: fixed; inset: 0; z-index: 0;
background:
radial-gradient(ellipse 80% 50% at 10% 0%, rgba(255,107,53,0.18) 0%, transparent 60%),
radial-gradient(ellipse 60% 40% at 90% 100%, rgba(0,78,137,0.2) 0%, transparent 60%),
radial-gradient(ellipse 50% 60% at 50% 50%, rgba(26,147,111,0.08) 0%, transparent 70%);
animation: meshShift 8s ease-in-out infinite alternate;
}
@keyframes meshShift {
0% { filter: hue-rotate(0deg); }
100% { filter: hue-rotate(15deg); }
}

/* Geometric decorations */
.geo {
position: fixed; pointer-events: none; z-index: 0;
}
.geo-1 {
top: -80px; right: -80px;
width: 300px; height: 300px;
border: 2px solid rgba(255,107,53,0.12);
border-radius: 50%;
animation: spin 20s linear infinite;
}
.geo-2 {
bottom: -60px; left: -60px;
width: 250px; height: 250px;
border: 2px solid rgba(0,78,137,0.15);
transform: rotate(45deg);
animation: spin 25s linear infinite reverse;
}
.geo-3 {
top: 40%; right: -40px;
width: 120px; height: 120px;
border: 1px solid rgba(255,107,53,0.1);
border-radius: 50%;
animation: float 6s ease-in-out infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-20px)} }

.page {
position: relative; z-index: 1;
min-height: 100vh;
display: flex;
flex-direction: column;
align-items: center;
padding: 0 16px 80px;
}

/* ── HERO HEADER ── */
.hero {
width: 100%;
max-width: 640px;
padding-top: 50px;
text-align: center;
margin-bottom: 40px;
animation: heroIn 1s cubic-bezier(.16,1,.3,1) both;
}
@keyframes heroIn {
from { opacity: 0; transform: translateY(-40px); }
to   { opacity: 1; transform: translateY(0); }
}

.school-tag {
display: inline-flex;
align-items: center;
gap: 8px;
background: rgba(255,107,53,0.12);
border: 1px solid rgba(255,107,53,0.3);
color: var(–c1);
font-size: 11px;
font-weight: 600;
letter-spacing: 3px;
text-transform: uppercase;
padding: 6px 18px;
border-radius: 100px;
margin-bottom: 24px;
}
.school-tag::before, .school-tag::after {
content: ‘◆’;
font-size: 7px;
opacity: 0.7;
}

.event-name {
font-family: ‘Bebas Neue’, sans-serif;
font-size: clamp(5rem, 18vw, 9rem);
line-height: 0.9;
letter-spacing: 4px;
background: linear-gradient(135deg, #ff6b35 0%, #f7c59f 40%, #ffffff 60%, #ff6b35 100%);
background-size: 200% 200%;
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
animation: shimmer 4s ease infinite;
}
@keyframes shimmer {
0%,100% { background-position: 0% 50%; }
50% { background-position: 100% 50%; }
}

.version-tag {
font-family: ‘Bebas Neue’, sans-serif;
font-size: 1.4rem;
letter-spacing: 8px;
color: rgba(247,197,159,0.6);
margin-top: 4px;
}

.hero-divider {
display: flex;
align-items: center;
gap: 16px;
margin: 28px 0 16px;
}
.hero-divider::before, .hero-divider::after {
content: ‘’;
flex: 1;
height: 1px;
background: linear-gradient(90deg, transparent, rgba(255,107,53,0.5), transparent);
}
.hero-divider span {
color: var(–c1);
font-size: 18px;
}

.hero-sub {
color: var(–muted);
font-size: 13px;
letter-spacing: 1px;
line-height: 1.7;
}

/* ── FORM CARD ── */
.form-card {
width: 100%;
max-width: 560px;
background: var(–surface);
border: 1px solid var(–border);
border-radius: 28px;
padding: 44px 40px;
position: relative;
overflow: hidden;
animation: cardIn 1s cubic-bezier(.16,1,.3,1) 0.2s both;
box-shadow:
0 0 0 1px rgba(255,255,255,0.04) inset,
0 40px 80px rgba(0,0,0,0.6),
0 0 60px rgba(255,107,53,0.06);
}
@keyframes cardIn {
from { opacity: 0; transform: translateY(40px); }
to   { opacity: 1; transform: translateY(0); }
}

/* Orange top accent bar */
.card-accent {
position: absolute;
top: 0; left: 0; right: 0;
height: 3px;
background: linear-gradient(90deg, transparent, var(–c1), #f7c59f, var(–c1), transparent);
animation: accentPulse 3s ease infinite;
}
@keyframes accentPulse {
0%,100% { opacity: 0.7; }
50% { opacity: 1; }
}

.form-title {
font-family: ‘Bebas Neue’, sans-serif;
font-size: 1.6rem;
letter-spacing: 4px;
color: var(–c2);
margin-bottom: 32px;
display: flex;
align-items: center;
gap: 12px;
}
.form-title::after {
content: ‘’;
flex: 1;
height: 1px;
background: var(–border);
}

/* Step indicators */
.steps {
display: flex;
gap: 8px;
margin-bottom: 32px;
}
.step-dot {
flex: 1;
height: 3px;
border-radius: 3px;
background: rgba(240, 28, 28, 0.08);
transition: background 0.3s;
}
.step-dot.active { background: var(–c1); }

.field {
margin-bottom: 22px;
position: relative;
}

.field label {
display: block;
font-size: 11px;
font-weight: 600;
letter-spacing: 2px;
color: rgb(209 97 11);
text-transform: uppercase;
margin-bottom: 10px;
}

.field input,
.field select {
width: 100%;
background: rgba(255,255,255,0.04);
border: 1.5px solid rgba(255,255,255,0.08);
border-radius: 14px;
padding: 15px 20px;
color: var(–text);
font-family: ‘Poppins’, sans-serif;
font-size: 15px;
font-weight: 500;
outline: none;
transition: all 0.25s;
-webkit-appearance: none;
appearance: none;
}

.field input:focus,
.field select:focus {
border-color: var(–c1);
background: rgba(255,107,53,0.06);
box-shadow: 0 0 0 4px rgba(255,107,53,0.1);
transform: translateY(-1px);
}

.field input::placeholder { color: rgba(136,136,136,0.6); }
.field select option { background: linear-gradient(135deg, #ff6b35, #e8502a); }

/* Custom select arrow */
.select-wrap { position: relative; }
.select-wrap::after {
content: ‘▾’;
position: absolute;
right: 18px;
top: 50%;
transform: translateY(-50%);
color: var(–c1);
pointer-events: none;
font-size: 14px;
}

.row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

/* Phone prefix */
.phone-wrap { position: relative; }
.phone-prefix {
position: absolute;
left: 20px;
top: 50%;
transform: translateY(-50%);
color: var(–c1);
font-weight: 600;
font-size: 15px;
pointer-events: none;
}
.phone-wrap input { padding-left: 52px; }

/* Submit */
.btn-submit {
width: 100%;
padding: 18px;
margin-top: 8px;
background: linear-gradient(135deg, #ff6b35, #e8502a);
border: none;
border-radius: 16px;
color: #fff;
font-family: ‘Poppins’, sans-serif;
font-size: 15px;
font-weight: 700;
letter-spacing: 2px;
text-transform: uppercase;
cursor: pointer;
position: relative;
overflow: hidden;
transition: all 0.3s;
box-shadow: 0 8px 32px rgba(255,107,53,0.35);
}
.btn-submit::before {
content: ‘’;
position: absolute;
top: 0; left: -100%;
width: 100%; height: 100%;
background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
transition: left 0.5s;
}
.btn-submit:hover::before { left: 100%; }
.btn-submit:hover {
transform: translateY(-2px);
box-shadow: 0 12px 40px rgba(255,107,53,0.5);
}
.btn-submit:active { transform: translateY(0); }

/* ── GOOGLE REVIEW ── */
.review-card {
width: 100%;
max-width: 560px;
margin-top: 20px;
background: var(–surface);
border: 1px solid rgba(255,255,255,0.07);
border-radius: 24px;
padding: 28px 32px;
animation: cardIn 1s cubic-bezier(.16,1,.3,1) 0.4s both;
}

.review-label {
font-size: 11px;
font-weight: 600;
letter-spacing: 3px;
color: var(–muted);
text-transform: uppercase;
margin-bottom: 14px;
}

.google-review-btn {
display: flex;
align-items: center;
gap: 14px;
width: 100%;
padding: 16px 22px;
background: #fff;
border: none;
border-radius: 14px;
text-decoration: none;
transition: all 0.25s;
box-shadow: 0 4px 24px rgba(0,0,0,0.3);
}
.google-review-btn:hover {
transform: translateY(-2px);
box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}

.g-icon {
width: 28px; height: 28px; flex-shrink: 0;
background: url(‘data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="%234285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="%2334A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="%23FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="%23EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>’) no-repeat center / contain;
}

.g-text { flex: 1; }
.g-text strong {
display: block;
font-family: ‘Poppins’, sans-serif;
font-size: 14px;
font-weight: 700;
color: #1a1a1a;
}
.g-text span {
font-size: 12px;
color: #777;
}

.stars-display {
display: flex;
gap: 2px;
}
.stars-display span { font-size: 16px; }

/* ── TOAST ── */
.toast {
position: fixed;
bottom: 32px; left: 50%;
transform: translateX(-50%) translateY(100px);
background: linear-gradient(135deg, var(–c5), #126b52);
color: #fff;
padding: 16px 32px;
border-radius: 100px;
font-size: 14px;
font-weight: 600;
letter-spacing: 0.5px;
box-shadow: 0 12px 40px rgba(0,0,0,0.5);
z-index: 999;
transition: transform 0.4s cubic-bezier(.16,1,.3,1);
white-space: nowrap;
}
.toast.show { transform: translateX(-50%) translateY(0); }

@media(max-width:520px) {
.form-card { padding: 32px 22px; }
.row-2 { grid-template-columns: 1fr; }
.review-card { padding: 22px 18px; }
}
</style>

</head>
<body>

<div class="bg-mesh"></div>
<div class="geo geo-1"></div>
<div class="geo geo-2"></div>
<div class="geo geo-3"></div>

<div class="page">

  <!-- HERO -->

  <div class="hero">
    <div class="school-tag">Mother Care School · Nadiad</div>
    <div class="event-name">ADMIRIA</div>
    <div class="version-tag">E D I T I O N &nbsp; 1 . 0</div>
    <div class="hero-divider"><span>✦</span></div>
    <p class="hero-sub">Fill in your details below to officially register<br>for the most awaited school event of the year.</p>
  </div>

  <!-- FORM -->

  <div class="form-card">
    <div class="card-accent"></div>
    <div class="form-title">Registration</div>

<div class="steps">
  <div class="step-dot active" id="s1"></div>
  <div class="step-dot" id="s2"></div>
  <div class="step-dot" id="s3"></div>
  <div class="step-dot" id="s4"></div>
</div>

<div class="field">
  <label>Student's Full Name *</label>
  <input type="text" id="name" placeholder="e.g. Aryan Patel" autocomplete="off" oninput="updateSteps()" />
</div>

<div class="row-2">
  <div class="field">
    <label>Standard / Class *</label>
    <div class="select-wrap">
      <select id="std" onchange="updateSteps()">
        <option value="">Select Class</option>
        <optgroup label="Pre-Primary">
          <option>Nursery</option>
          <option>Jr. KG</option>
          <option>Sr. KG</option>
        </optgroup>
        <optgroup label="Primary">
          <option>1st Std</option>
          <option>2nd Std</option>
          <option>3rd Std</option>
          <option>4th Std</option>
          <option>5th Std</option>
        </optgroup>
        <optgroup label="Middle">
          <option>6th Std</option>
          <option>7th Std</option>
          <option>8th Std</option>
        </optgroup>
        <optgroup label="Secondary">
          <option>9th Std</option>
          <option>10th Std</option>
        </optgroup>
        <optgroup label="Higher Secondary">
          <option>11th Std</option>
          <option>12th Std</option>
        </optgroup>
      </select>
    </div>
  </div>
  <div class="field">
    <label>Division</label>
    <div class="select-wrap">
      <select id="division">
        <option value="">Select Div</option>
        <option>A</option><option>B</option>
        <option>C</option><option>D</option>
      </select>
    </div>
  </div>
</div>

<div class="field">
  <label>Contact Number *</label>
  <div class="phone-wrap">
    <span class="phone-prefix">+91</span>
    <input type="tel" id="contact" placeholder="10-digit mobile number" maxlength="10" oninput="updateSteps()" />
  </div>
</div>

<div class="field">
  <label>Parent's Name</label>
  <input type="text" id="parent" placeholder="Father / Mother name" oninput="updateSteps()" />
</div>

<button class="btn-submit" onclick="register()">
  ✦ &nbsp; Complete Registration &nbsp; ✦
</button>

  </div>

  <!-- GOOGLE REVIEW -->

  <div class="review-card">
    <div class="review-label">⭐ Loved our school? Share it!</div>
    <a class="google-review-btn"
       href="https://www.google.com/search?client=safari&hs=s0R&sca_esv=da0365bf5fc892c6&hl=en-in&cs=1&output=search&kgmid=%2Fg%2F1pty_ss78&q=Mother%20Care%20-%20Best%20CBSE%20%26%20GSEB%20School%20in%20Nadiad%2C%20kheda%20district.&shem=epsd1%2Crimspwouoe&shndl=30&source=sh%2Fx%2Floc%2Fact%2Fm4%2F3"
       target="_blank" rel="noopener">
      <div class="g-icon"></div>
      <div class="g-text">
        <strong>Rate Mother Care School</strong>
        <span>Write a Google Review — it helps us grow!</span>
      </div>
      <div class="stars-display">
        <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
      </div>
    </a>
  </div>

</div>

<div class="toast" id="toast">✅ Registered Successfully!</div>

<script>
function updateSteps() {
  const name = document.getElementById('name').value.trim();
  const std  = document.getElementById('std').value;
  const contact = document.getElementById('contact').value.trim();
  const parent = document.getElementById('parent').value.trim();
  document.getElementById('s1').classList.toggle('active', !!name);
  document.getElementById('s2').classList.toggle('active', !!std);
  document.getElementById('s3').classList.toggle('active', contact.length === 10);
  document.getElementById('s4').classList.toggle('active', !!parent);
}

function register() {
  const name    = document.getElementById('name').value.trim();
  const std     = document.getElementById('std').value;
  const contact = document.getElementById('contact').value.trim();
  const division = document.getElementById('division').value;
  const parent  = document.getElementById('parent').value.trim();

  if (!name)    { shake('name'); return; }
  if (!std)     { shake('std'); return; }
  if (contact.length !== 10 || isNaN(contact)) {
    shake('contact');
    alert('Please enter valid number');
    return;
  }

  fetch("save.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: `name=${name}&std=${std}&division=${division}&contact=${contact}&parent=${parent}`
  })
  .then(res => res.text())
  .then(data => {
    if (data === "success") {

      const t = document.getElementById('toast');
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 3500);

      document.getElementById('name').value = '';
      document.getElementById('contact').value = '';
      document.getElementById('parent').value = '';
      document.getElementById('std').value = '';
      document.getElementById('division').value = '';
      updateSteps();

    } else {
      alert("Error saving data!");
    }
  });
}

function shake(id) {
  const el = document.getElementById(id);
  el.style.animation = 'none';
  el.offsetHeight;
  el.style.animation = 'shake 0.4s ease';
  setTimeout(() => el.style.animation = '', 400);
}

const style = document.createElement('style');
style.textContent = `@keyframes shake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-6px)} 40%,80%{transform:translateX(6px)} }`;
document.head.appendChild(style);
</script>

</body>
</html>