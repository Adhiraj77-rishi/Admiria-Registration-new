-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2026 at 08:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mothercareschool`
--

-- --------------------------------------------------------

--
-- Table structure for table `admiria_registrations`
--

CREATE TABLE `admiria_registrations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `std` varchar(50) NOT NULL,
  `division` varchar(10) DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `parent` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admiria_registrations`
--

INSERT INTO `admiria_registrations` (`id`, `name`, `std`, `division`, `contact`, `parent`, `created_at`) VALUES
(2, 'Test', '10th Std', 'B', '9875642561', 'Test father', '2026-04-28 06:12:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admiria_registrations`
--
ALTER TABLE `admiria_registrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admiria_registrations`
--
ALTER TABLE `admiria_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
